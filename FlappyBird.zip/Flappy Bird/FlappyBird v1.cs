﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyBird
{
    
    public partial class Form1 : Form
    {
        int pipeSpeed = 8;
        int gravity = 15;
        int score = 0;

        bool gameOver = false;
        Random rnd = new Random();


        public Form1()
        {
            InitializeComponent();

            ground.Controls.Add(scoreText);
            scoreText.Left = 20;
            scoreText.Top = 25;

            restartGame();
        }

        private void gameTimerEvent(object sender, EventArgs e)
        {
            flappyBird.Top += gravity;
            pipeBottom.Left -= pipeSpeed;
            pipeBottom1.Left -= pipeSpeed;
            pipeTop.Left -= pipeSpeed;
            pipeTop1.Left -= pipeSpeed;
            scoreText.Text = "Score: " + score;

            if (pipeBottom.Left < -150) 
            {
                pipeBottom.Left = rnd.Next(750, 1300);
                score++;
            }
            if (pipeBottom1.Left < -150)
            {
                pipeBottom1.Left = rnd.Next(1000, 1550);
                score++;
            }
            if (pipeTop.Left < -180)
            {
                pipeTop.Left = rnd.Next(850, 1500);
                score++;
            }
            if (pipeTop1.Left < -180)
            {
                pipeTop1.Left = rnd.Next(1100, 1750);
                score++;
            }

            if (flappyBird.Bounds.IntersectsWith(pipeBottom.Bounds) ||
                flappyBird.Bounds.IntersectsWith(pipeBottom1.Bounds) ||
                flappyBird.Bounds.IntersectsWith(pipeTop.Bounds) ||
                flappyBird.Bounds.IntersectsWith(pipeTop1.Bounds) ||
                flappyBird.Bounds.IntersectsWith(ground.Bounds) ||
                (flappyBird.Top < -21)
                )
            {
                endGame();
            }

            if (score > 1)
            {
                pipeSpeed = 10;
            }

       
        }   

    private void gameKeyIsDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Space)
            {
                gravity = -15;
            }
        }

        private void gameKeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = 15;
            }
            if(e.KeyCode == Keys.R && gameOver)
            {
                restartGame();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void endGame()
        {
            gameTimer.Stop();
            scoreText.Text += " Game Over! Press R to Restart";
            gameOver = true;
            restartImage.Enabled = true;
            restartImage.Visible = true;
        }

        private void restartGame()
        {
            gameOver = false;
            flappyBird.Location = new Point(69, 228);
            pipeTop.Left = 800;
            pipeTop1.Left = 1050;
            pipeBottom.Left = 1200;
            pipeBottom1.Left = 1450;

            score = 0;
            pipeSpeed = 8;
            scoreText.Text = "Score: 0";
            gameTimer.Start();
            restartImage.Enabled = false;
            restartImage.Visible = false;
        }

        private void RestartClickEvent(object sender, EventArgs e)
        {
            restartGame();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
